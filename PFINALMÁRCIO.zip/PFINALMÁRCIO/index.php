<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechServices - Soluções em TI</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <header>
        <div class="logo">TechServices</div>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="produtos.php">Catálogo de Serviços</a></li>
            </ul>
        </nav>
    </header>

    <div class="container">
        <section class="banner-home">
            <h2>Transforme a Infraestrutura da sua Empresa</h2>
            <p>Gerenciamento de TI, segurança cibernética e suporte técnico de alto nível.</p>
        </section>

        <h2 style="color: #1e293b; margin-bottom: 15px;">Nossos Diferenciais</h2>
        <div class="grid-cards">
            <div class="card card-corpo">
                <h3>Monitoramento 24/7</h3>
                <p>Equipe dedicada monitorando seus servidores e redes em tempo integral para evitar paradas.</p>
            </div>
            <div class="card card-corpo">
                <h3>Segurança Avançada</h3>
                <p>Proteção contra ameaças virtuais, implementação de firewalls e rotinas de backup.</p>
            </div>
            <div class="card card-corpo">
                <h3>Atendimento Ágil</h3>
                <p>Suporte remoto e presencial focado em resolver chamados com máxima prioridade.</p>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> TechServices. Todos os direitos reservados.</p>
    </footer>

</body>
</html>