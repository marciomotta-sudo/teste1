<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechServices - Catálogo de Serviços</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <header>
        <div class="logo">TechServices</div>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="produtos.php">Catálogo de Serviços</a></li>
            </ul>
        </nav>
    </header>

    <div class="container">
        <h2 style="color: #1e293b; margin-bottom: 10px;">Catálogo de Serviços</h2>
        <p style="color: #64748b; margin-bottom: 20px;">Utilize o campo de busca para filtrar nossas soluções em tempo real:</p>

        <!-- Filtro JS -->
        <div class="busca-container">
            <input type="text" id="inputBusca" class="campo-busca" placeholder="Digite para buscar um serviço (ex: Nuvem, Segurança, Suporte)...">
        </div>

        <!-- Catálogo de Serviços -->
        <div class="grid-cards">
            
            <div class="card card-item">
                <img src="img/nuvem.jpg" alt="Computação em Nuvem">
                <div class="card-corpo">
                    <h3>Gestão de Nuvem</h3>
                    <p>Migração e gerenciamento de servidores em ambientes AWS, Azure e Google Cloud com alta disponibilidade.</p>
                    <span class="preco-tag">A partir de R$ 850,00/mês</span>
                </div>
            </div>

            <div class="card card-item">
                <img src="img/seguranca.jpg" alt="Segurança Cibernética">
                <div class="card-corpo">
                    <h3>Auditoria de Segurança</h3>
                    <p>Testes de vulnerabilidade, proteção de dados e adequação às políticas de segurança da informação.</p>
                    <span class="preco-tag">A partir de R$ 1.200,00/projeto</span>
                </div>
            </div>

            <div class="card card-item">
                <img src="img/suporte.jpg" alt="Suporte Técnico">
                <div class="card-corpo">
                    <h3>Suporte Técnico Especializado</h3>
                    <p>Manutenção preventiva e corretiva de computadores, redes locais e sistemas corporativos.</p>
                    <span class="preco-tag">A partir de R$ 450,00/mês</span>
                </div>
            </div>

        </div>

        <!-- Formulário para envio em POST -->
        <section class="form-secao">
            <h3 style="color: #1e293b; margin-bottom: 15px;">Solicitar Orçamento / Contato</h3>
            
            <form action="processa.php" method="POST">
                <div class="grupo-campo">
                    <label for="nome">Nome Completo:*</label>
                    <input type="text" id="nome" name="nome" required>
                </div>

                <div class="grupo-campo">
                    <label for="email">E-mail Corporativo:*</label>
                    <input type="email" id="email" name="email" required>
                </div>

                <div class="grupo-campo">
                    <label for="servico">Serviço de Interesse:*</label>
                    <select id="servico" name="servico" required>
                        <option value="">Selecione um serviço...</option>
                        <option value="Gestão de Nuvem">Gestão de Nuvem</option>
                        <option value="Auditoria de Segurança">Auditoria de Segurança</option>
                        <option value="Suporte Técnico Especializado">Suporte Técnico Especializado</option>
                    </select>
                </div>

                <div class="grupo-campo">
                    <label for="mensagem">Descrição da Necessidade:*</label>
                    <textarea id="mensagem" name="mensagem" rows="4" required></textarea>
                </div>

                <button type="submit" class="btn-enviar">Enviar Solicitação</button>
            </form>
        </section>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> TechServices. Todos os direitos reservados.</p>
    </footer>

    <script src="js/script.js"></script>
</body>
</html>