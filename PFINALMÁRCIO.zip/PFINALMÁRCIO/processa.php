<?php
// Proteção contra acesso direto via GET
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: produtos.php');
    exit();
}

$nome = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$servico = $_POST['servico'] ?? '';
$mensagem = trim($_POST['mensagem'] ?? '');

date_default_timezone_set('America/Sao_Paulo');
$dataRegistro = date('d/m/Y H:i:s');
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechServices - Confirmação</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <header>
        <div class="logo">TechServices</div>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="produtos.php">Catálogo de Serviços</a></li>
            </ul>
        </nav>
    </header>

    <div class="container">
        <?php if (!empty($nome) && !empty($email) && !empty($servico) && !empty($mensagem)): ?>
            
            <div style="background: #ffffff; border: 1px solid #10b981; border-radius: 8px; padding: 30px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
                <h2 style="color: #059669; margin-bottom: 10px;">Solicitação Recebida com Sucesso!</h2>
                <p style="color: #4b5563;">Obrigado pelo contato, <strong><?= htmlspecialchars($nome); ?></strong>. Nossa equipe técnica analisará sua demanda em breve.</p>
                
                <hr style="margin: 20px 0; border: 0; border-top: 1px solid #e5e7eb;">

                <p style="margin-bottom: 8px;"><strong>E-mail:</strong> <?= htmlspecialchars($email); ?></p>
                <p style="margin-bottom: 8px;"><strong>Serviço Selecionado:</strong> <?= htmlspecialchars($servico); ?></p>
                <p style="margin-bottom: 8px;"><strong>Data e Hora:</strong> <?= $dataRegistro; ?></p>
                
                <div style="margin-top: 15px;">
                    <strong>Detalhamento Enviado:</strong>
                    <div style="background: #f9fafb; border: 1px solid #e5e7eb; padding: 12px; border-radius: 6px; margin-top: 6px; color: #374151;">
                        <?= nl2br(htmlspecialchars($mensagem)); ?>
                    </div>
                </div>

                <br>
                <a href="produtos.php" class="btn-enviar" style="text-decoration: none; display: inline-block;">Voltar ao Catálogo</a>
            </div>

        <?php else: ?>

            <div style="background: #ffffff; border: 1px solid #ef4444; border-radius: 8px; padding: 30px;">
                <h2 style="color: #dc2626; margin-bottom: 10px;">Falha no Processamento</h2>
                <p style="color: #4b5563;">Todos os campos obrigatórios precisam ser preenchidos corretamente.</p>
                <br>
                <a href="produtos.php" class="btn-enviar" style="background-color: #dc2626; text-decoration: none; display: inline-block;">Voltar e Corrigir</a>
            </div>

        <?php endif; ?>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> TechServices. Todos os direitos reservados.</p>
    </footer>

</body>
</html>