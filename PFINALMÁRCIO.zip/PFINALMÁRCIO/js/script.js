// Filtro Dinâmico de Serviços via DOM
document.addEventListener('DOMContentLoaded', function() {
    const inputBusca = document.getElementById('inputBusca');
    const cardsServico = document.querySelectorAll('.card-item');

    if (inputBusca) {
        inputBusca.addEventListener('input', function() {
            const termoBusca = inputBusca.value.toLowerCase().trim();

            cardsServico.forEach(function(card) {
                const titulo = card.querySelector('h3').textContent.toLowerCase();
                const descricao = card.querySelector('p').textContent.toLowerCase();

                if (titulo.includes(termoBusca) || descricao.includes(termoBusca)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }
});